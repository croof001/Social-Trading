CKEDITOR.editorConfig = function( config )
{
    config.extraPlugins = 'autosave';
};
